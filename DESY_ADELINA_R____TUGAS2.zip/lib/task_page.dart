import 'package:flutter/material.dart';

class TaskPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Plan'),
      ),
      body: Padding(
        padding: EdgeInsets.all(16), // padding
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start, // memposisikam teks ke kiri
          children: [
            Padding(
              padding: EdgeInsets.symmetric(vertical: 8), // kasih padding vertikal 8
              child: Progress(),
            ),
            TaskList(),
          ],
        ),
      ),
    );
  }
}

class Progress extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: EdgeInsets.only(bottom: 8), // nambah mb 8
          child: Text(
            'You are this far away from exploring the whole universe:',
            style: TextStyle(fontSize: 14),
          ),
        ),
        LinearProgressIndicator(value: 0.0),
      ],
    );
  }
}

class TaskItem extends StatelessWidget {
  final String label;
  TaskItem({Key? key, required this.label}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.symmetric(vertical: 4), // nambah margin vertikal
      child: Row(
        children: [
          Checkbox(
            value: false,
            onChanged: null,
          ),
          Padding(
            padding: EdgeInsets.only(left: 8), // nambah margin kiri
            child: Text(label),
          ),
        ],
      ),
    );
  }
}

class TaskList extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        TaskItem(label: 'Load rocket with supplies'),
        TaskItem(label: 'Launch rocket'),
        TaskItem(label: 'Circle the home planet'),
        TaskItem(label: 'Head out to the first moon'),
        TaskItem(label: 'Launch moon lander #1'),
      ],
    );
  }
}
